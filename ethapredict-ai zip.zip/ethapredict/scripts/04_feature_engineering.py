"""
Phase 6 — Feature Engineering
=================================
Builds derived features on top of the cleaned dataset:
  - Fuel_Efficiency_kmpl        : Distance / Fuel consumed
  - Consumption_Rate_Lpkm       : Fuel consumed / Distance  (isolates per-km driving effects)
  - Fuel_Per_Hour_L             : Fuel consumed / Driving time
  - Traffic_Score               : weighted composite of traffic + road type
  - Driving_Intensity           : composite of speed + acceleration + RPM
  - AC_Load_Indicator           : AC usage combined with temperature (AC works harder when hot)
  - Remaining_Range_km          : Fuel_Remaining_L * efficiency (uses OWN row's efficiency as a
                                   sanity-check feature; at inference time this will instead use
                                   the MODEL's predicted efficiency - see 05_prediction_engine.py)
  - Remaining_Time_hr           : Remaining_Range_km / Speed_kmph

These features feed Phase 7 (model training) and Phase 9 (the prediction engine).
"""

import numpy as np
import pandas as pd

CLEAN_PATH = "/home/claude/ethapredict/data/ethapredict_clean.csv"
FEATURED_PATH = "/home/claude/ethapredict/data/ethapredict_featured.csv"


def engineer_features(df):
    df = df.copy()

    # Avoid division-by-zero landmines
    safe_distance = df["Distance_Travelled_km"].replace(0, np.nan)
    safe_speed = df["Speed_kmph"].replace(0, np.nan)
    safe_time = df["Driving_Time_hr"].replace(0, np.nan)

    # 1. Fuel efficiency (km/L) — higher is better
    df["Fuel_Efficiency_kmpl"] = (safe_distance / df["Fuel_Consumed_L"]).clip(upper=40)

    # 2. Consumption rate (L/km) — isolates per-km driving-condition effects from trip length
    df["Consumption_Rate_Lpkm"] = (df["Fuel_Consumed_L"] / safe_distance).clip(upper=1.0)

    # 3. Fuel consumed per hour of driving
    df["Fuel_Per_Hour_L"] = (df["Fuel_Consumed_L"] / safe_time).clip(upper=25)

    # 4. Traffic score: combine traffic level with road type penalty
    road_penalty = df["Road_City"] * 0.3 + df["Road_Rural"] * 0.1  # Highway = 0 penalty
    df["Traffic_Score"] = df["Traffic_Level"] / 2.0 + road_penalty  # normalized 0-1.3ish

    # 5. Driving intensity: normalized composite of speed, acceleration, RPM
    speed_norm = (df["Speed_kmph"] / df["Speed_kmph"].max())
    accel_norm = (df["Acceleration"] / df["Acceleration"].max())
    rpm_norm = (df["RPM"] / df["RPM"].max())
    df["Driving_Intensity"] = (speed_norm + accel_norm + rpm_norm) / 3

    # 6. AC load indicator: AC usage matters more when it's hot
    df["AC_Load_Indicator"] = df["AC"] * (df["Temperature_C"] / df["Temperature_C"].max())

    # 7. Remaining range & time (diagnostic features; true inference-time versions
    #    are computed in the prediction engine using the MODEL's predicted efficiency,
    #    not the ground-truth efficiency used here)
    df["Remaining_Range_km"] = df["Fuel_Remaining_L"] * df["Fuel_Efficiency_kmpl"]
    df["Remaining_Time_hr"] = df["Remaining_Range_km"] / safe_speed

    # Fill any residual NaNs created by the safe-division guards with column medians
    new_cols = ["Fuel_Efficiency_kmpl", "Consumption_Rate_Lpkm", "Fuel_Per_Hour_L",
                "Remaining_Range_km", "Remaining_Time_hr"]
    for col in new_cols:
        df[col] = df[col].fillna(df[col].median())

    return df


if __name__ == "__main__":
    df = pd.read_csv(CLEAN_PATH)
    df_feat = engineer_features(df)
    df_feat.to_csv(FEATURED_PATH, index=False)

    print(f"Feature-engineered dataset saved: {df_feat.shape}")
    print("\nNew feature summary:")
    new_cols = ["Fuel_Efficiency_kmpl", "Consumption_Rate_Lpkm", "Fuel_Per_Hour_L",
                "Traffic_Score", "Driving_Intensity", "AC_Load_Indicator",
                "Remaining_Range_km", "Remaining_Time_hr"]
    print(df_feat[new_cols].describe().T[["mean", "std", "min", "max"]])
